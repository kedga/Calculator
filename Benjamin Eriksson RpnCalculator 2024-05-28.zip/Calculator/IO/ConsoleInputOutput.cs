﻿using Calculator.Utilities;

namespace Calculator.IO;

public class ConsoleInputOutput : IInputOutput
{
	public string GetInput()
    {
        return Console.ReadLine()?.Trim() ?? "";
	}

	public void PushOutput(string text)
    {
        Console.WriteLine(text);
    }
}
