﻿using Calculator.Utilities;

namespace Calculator.IO;

public interface IInputOutput
{
	void PushOutput(string text);
	string GetInput();
}
