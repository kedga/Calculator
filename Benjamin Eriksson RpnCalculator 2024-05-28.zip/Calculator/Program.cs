﻿using System;
using System.Numerics;
using System.Text;
using Calculator.Calculator;
using Calculator.IO;
using static Calculator.Calculator.RpnCalculator;

namespace Calculator;

class Program
{
	static void Main(string[] args)
	{
		var io = new ConsoleInputOutput();

		var calculator = new ConsoleLikeRpnCalculator(io);

		calculator.Run();
	}
}