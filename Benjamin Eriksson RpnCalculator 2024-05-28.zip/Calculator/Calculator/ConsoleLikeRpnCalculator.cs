﻿using Calculator.IO;
using Calculator.Utilities;

namespace Calculator.Calculator;

public class ConsoleLikeRpnCalculator(IInputOutput io) : StringRpnCalculator(io)
{
    public void Run()
    {
        while (true)
        {
            if (StackCount < 1)
            {
                OutputMessage = "Commands: q c + - * / number";
				IO.PushOutput(OutputMessage);
			}

            OutputMessage = PrintStackContents();
			IO.PushOutput(OutputMessage);

            string input = IO.GetInput();

            if (input.Length < 1) continue;

            if (TryAddValue(input)) continue;

            if (input.Equals("c", StringComparison.CurrentCultureIgnoreCase)) Clear();

            else if (input.Equals("q", StringComparison.CurrentCultureIgnoreCase)) break;

			else if (TryGetOperator(input) is Operator validOperator)
			{
				var isOperationSuccessful = TryPerformOperation(validOperator);

				if (isOperationSuccessful) continue;

				else
				{
					IO.PushOutput(OutputMessage);
					continue;
				};
			}

			else
            {
                OutputMessage = "Illegal command, ignored";
                IO.PushOutput(OutputMessage);
            }
        }
    }
}
