﻿namespace Calculator.Utilities;

public record OperationResult(bool IsSuccess, string Message);