﻿namespace Calculator.Utilities;

public enum Operator
{
    Add,
    Subtract,
    Multiply,
    Divide
}